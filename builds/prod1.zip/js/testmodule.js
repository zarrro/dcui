var exports = function(s) {
    console.log("Hello " + s);
}